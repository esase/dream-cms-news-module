<?php 

return [
	'module_path' => 'module/News',
    'layout_path' => 'layout/news'
];
