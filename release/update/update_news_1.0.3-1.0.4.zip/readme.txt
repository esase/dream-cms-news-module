News update 1.0.4

System requirements: 
Module depends:

