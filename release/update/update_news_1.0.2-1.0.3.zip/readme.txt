News update 1.0.3

System requirements: 
Module depends:

