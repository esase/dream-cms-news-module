News update 1.0.5
System requirements: 
Module depends:

