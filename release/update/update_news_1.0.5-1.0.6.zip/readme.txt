News update 1.0.6
System requirements: 
Module depends:

