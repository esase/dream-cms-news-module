UPDATE `page_system` SET `dynamic_page` = 1 WHERE `slug` = 'news';
UPDATE `page_system` SET `dynamic_page` = NULL WHERE `slug` = 'news-list';
