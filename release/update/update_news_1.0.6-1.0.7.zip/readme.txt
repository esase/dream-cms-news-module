News update 1.0.7
System requirements: 
Module depends:

