DROP TABLE IF EXISTS `news_category_connection`;
DROP TABLE IF EXISTS `news_category`;
DROP TABLE IF EXISTS `news_list`;
