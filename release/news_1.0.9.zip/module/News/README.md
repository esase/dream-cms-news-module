# News
News module for Dream CMS. Module allows to publish news on the site.
