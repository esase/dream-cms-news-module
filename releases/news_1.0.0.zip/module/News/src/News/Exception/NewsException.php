<?php
namespace News\Exception;
use Exception;

class NewsException extends Exception
{}