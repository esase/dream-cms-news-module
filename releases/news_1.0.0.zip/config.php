<?php 

return [
	'module_path' => 'module/News'
];
