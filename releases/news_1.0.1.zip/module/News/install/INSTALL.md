# INSTALLATION
Install this module via the admin panel.

## CRON JOBS

## PERMISSIONS

## APACHE SETTINGS

## PHP SETTINGS

